from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Movie, Post,Like
from .forms import MovieForm


# Create your views here.
def signup(request):
    return render(request, "signup.html")
def login(request):
    return render(request, "login.html")


def add_movie(request):
    if request.method=="POST":
        title=request.POST.get('title',)
        description = request.POST.get('description', )
        save_date = request.POST.get('save_date', )
        author = request.POST.get('author',)
        movie=Movie(title=title,description=description,save_date=save_date,author=author)

    return render(request,'add.html')

def post_list(request):
    posts = Post.objects.all()

    # for post in posts:
    #     post.like_count = Like.objects.filter(post=post).count()  # Count likes for each post
    #     post.created_at_formatted = post.created_at.strftime("%d-%m-%Y")  # Format date

    context = {
        'posts': posts,
    }
    return render(request, 'post_list.html', context)
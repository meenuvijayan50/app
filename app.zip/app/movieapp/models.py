from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
# from .tag import Tag
# Create your models here.


class Movie(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    save_date = models.DateTimeField()  # Use this field for the save date
    author = models.CharField(max_length=50)
    def __str__(self):
        return self.title




class Post(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, through='Like', related_name='liked_posts')
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.username} likes {self.post.title}"


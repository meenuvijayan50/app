
from django.urls import path
from .import views



app_name='movieapp'
urlpatterns = [

    path('',views.signup,name='signup'),
    path('login', views.login, name='login'),
    path('add_movie',views.add_movie,name='add_movie'),
    path('post_list', views.post_list, name='post_list'),



]
